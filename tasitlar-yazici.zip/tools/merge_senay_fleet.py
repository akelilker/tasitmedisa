#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ŞENAY / MEDİSA-KARYAPI (+ isteğe bağlı Downloads’taki diğer listeler) araç
Excel'lerini ARAÇ ŞABLON sütunlarında birleştirir. Plaka anahtarı normalize edilir.
Kullanıcı alanı: UNVAN, FİRMA ve otomatik bulunan (Plaka + Ad/Kullanıcı/Tahsis…) sütunları
tekrarsız birleştirilir.

Çıktı: tools/output/SENAY_ARACLAR_MASTER.xlsx
"""
from __future__ import annotations

import re
from collections import defaultdict
from pathlib import Path

import openpyxl

DOWNLOADS = Path(r"C:\Users\Akel\Downloads")
HERE = Path(__file__).resolve().parent
OUT_DIR = HERE / "output"
OUT_FILE = OUT_DIR / "SENAY_ARACLAR_MASTER.xlsx"

# Birleştirmede atlanacak dosya adı parçaları (stok raporu, ekstre vb.)
SKIP_NAME_SUBSTR = (
    "MEDISA_STOK",
    "EKSTRE",
    "KREDI_KARTI",
    "DOCUMENT_",
    "202603R",
    "~$",
)


def norm_plate(value) -> str:
    if value is None:
        return ""
    s = str(value).strip().upper().replace(" ", "").replace("\n", "")
    return s


def cell_str(value) -> str | None:
    if value is None:
        return None
    s = str(value).strip()
    return s if s else None


def merge_unique_labels(*parts: str | None) -> str | None:
    """Tekrarları ve (uzun metin içinde geçen) kısa yineleri ele; kalanları ' | ' ile birleştir."""
    items: list[str] = []
    for p in parts:
        s = cell_str(p)
        if s:
            items.append(s)
    if not items:
        return None
    items.sort(key=len, reverse=True)
    result: list[str] = []
    for s in items:
        sl = s.lower()
        if any(sl == r.lower() for r in result):
            continue
        if any(sl in r.lower() and sl != r.lower() for r in result):
            continue
        result = [r for r in result if not (r.lower() in sl and r.lower() != sl)]
        result.append(s)
    result.sort(key=lambda x: x.lower())
    return " | ".join(result) if result else None


def kasko_kodu_from_tsb(marka_kdu, tip_kdu) -> str | None:
    a = re.sub(r"\D", "", str(marka_kdu or ""))
    b = re.sub(r"\D", "", str(tip_kdu or ""))
    if not a and not b:
        return None
    return a + b


def find_file(preds):
    for p in sorted(DOWNLOADS.glob("*.xlsx")):
        if p.name.startswith("~$"):
            continue
        u = p.name.upper()
        for pr in preds:
            if pr(u, p.name):
                return p
    return None


def should_skip_file(path: Path) -> bool:
    u = path.name.upper()
    return any(s in u for s in SKIP_NAME_SUBSTR)


def pick_template() -> Path:
    p = find_file(
        [
            lambda u, n: "ABLON" in u.replace("Ç", "C").replace("Ş", "S")
            and "ARAC" in u.replace("Ç", "C"),
            lambda u, n: "SABLON" in u or "ABLON" in u,
        ]
    )
    if not p:
        raise FileNotFoundError("ARAÇ ŞABLON xlsx bulunamadı")
    return p


def pick_senay() -> Path:
    p = find_file([lambda u, n: "GRUP" in u and "ARAC" in u.replace("Ç", "C")])
    if not p:
        raise FileNotFoundError("ŞENAY GRUP xlsx bulunamadı")
    return p


def pick_med() -> Path:
    p = find_file([lambda u, n: "KARYAPI" in u and "MED" in u])
    if not p:
        raise FileNotFoundError("MEDİSA-KARYAPI xlsx bulunamadı")
    return p


def pick_kasko() -> Path:
    p = find_file([lambda u, n: "KASKO" in u and "LIST" in u.replace("İ", "I")])
    if not p:
        raise FileNotFoundError("KASKO LİSTESİ xlsx bulunamadı")
    return p


def read_headers(ws) -> list:
    h = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
    while h and h[-1] is None:
        h.pop()
    return h


def norm_header(h) -> str:
    s = re.sub(r"\s+", " ", str(h or "").replace("\n", " ")).strip().upper()
    for a, b in (
        ("İ", "I"),
        ("Ş", "S"),
        ("Ğ", "G"),
        ("Ü", "U"),
        ("Ö", "O"),
        ("Ç", "C"),
    ):
        s = s.replace(a, b)
    return s


def header_col_exact(headers: list, *candidates: str) -> int | None:
    """İlk tam eşleşen sütun (Kullanıcı / Kullanıcı Telefon ayrımı için)."""
    cand = [norm_header(c) for c in candidates]
    for i, h in enumerate(headers):
        if not h or not isinstance(h, str):
            continue
        nh = norm_header(h)
        if nh in cand:
            return i
    return None


def header_col_contains(headers: list, must: str, must_not: tuple[str, ...] = ()) -> int | None:
    M = norm_header(must)
    for i, h in enumerate(headers):
        if not h or not isinstance(h, str):
            continue
        nh = norm_header(h)
        if M not in nh:
            continue
        if any(norm_header(x) in nh for x in must_not):
            continue
        return i
    return None


def is_plaka_column(H: str) -> bool:
    if "PLAKA" not in H and "PLATE" not in H:
        return False
    if "KULLANIM" in H:
        return False
    return True


def is_person_column(H: str) -> bool:
    if "KULLANIM" in H and "TARZI" in H:
        return False
    if "MARKA" in H and "KOD" in H:
        return False
    if "TİP" in H and "KOD" in H:
        return False
    if "MODEL" in H and "YILI" in H:
        return False
    needles = (
        "KULLANICI",
        "KULLANIC",
        "SÜRÜCÜ",
        "SURUCU",
        "ŞOFÖR",
        "SOFOR",
        "TAHSİS",
        "TAHSIS",
        "ZİMMET",
        "ZIMMET",
        "PERSONEL",
        "AD SOYAD",
        "ADSOYAD",
        "ADI SOYADI",
        " AD ",
        "SOYAD",
        "İSİM",
        "ISIM",
        "YETKİLİ",
        "YETKILI",
        "EKSPER",
        "SÜRÜCÜ ADI",
    )
    return any(n in H for n in needles)


def detect_plaka_name_columns(ws) -> tuple[int | None, list[int]]:
    """(plaka_col_1based, [name_cols]) ilk satır başlığından."""
    mc = ws.max_column or 0
    headers = [(c, norm_header(ws.cell(1, c).value)) for c in range(1, mc + 1)]
    plate_col = None
    for c, H in headers:
        if H and is_plaka_column(H):
            plate_col = c
            break
    name_cols = [c for c, H in headers if H and is_person_column(H)]
    return plate_col, name_cols


def iter_extra_plate_name_files(
    exclude_paths: set[Path],
) -> list[tuple[Path, str, int, list[int]]]:
    """
    Downloads’ta Plaka + kişi sütunlu sayfaları bul (şablon ve ana kaynaklar hariç).
    """
    found: list[tuple[Path, str, int, list[int]]] = []
    for p in sorted(DOWNLOADS.glob("*.xlsx")):
        if should_skip_file(p) or p.name.startswith("~$"):
            continue
        if p.resolve() in exclude_paths:
            continue
        try:
            wb = openpyxl.load_workbook(p, read_only=True, data_only=True)
        except Exception:
            continue
        for sn in wb.sheetnames:
            ws = wb[sn]
            pc, nc = detect_plaka_name_columns(ws)
            if pc and nc:
                found.append((p, sn, pc, nc))
        wb.close()
    return found


def load_extra_name_rows(
    entries: list[tuple[Path, str, int, list[int]]],
) -> dict[str, list[str]]:
    """plaka_key -> kişi metinleri listesi (tekrarlı olabilir)."""
    by_plate: dict[str, list[str]] = defaultdict(list)
    for path, sheet_name, pc, name_cols in entries:
        try:
            wb = openpyxl.load_workbook(path, data_only=True)
        except Exception:
            continue
        ws = wb[sheet_name]
        for r in range(2, ws.max_row + 1):
            k = norm_plate(ws.cell(r, pc).value)
            if not k:
                continue
            parts = []
            for c in name_cols:
                s = cell_str(ws.cell(r, c).value)
                if s:
                    parts.append(s)
            if parts:
                by_plate[k].append(" ".join(parts))
        wb.close()
    return by_plate


def row_senay(ws, r):
    plate = ws.cell(r, 3).value
    k = norm_plate(plate)
    if not k:
        return {}
    parts = [cell_str(ws.cell(r, c).value) or "" for c in (4, 5, 6)]
    bm = " ".join(x for x in parts if x).strip() or None
    yil = ws.cell(r, 7).value
    if isinstance(yil, float) and yil == int(yil):
        yil = int(yil)
    firma = cell_str(ws.cell(r, 2).value)
    kurum = cell_str(ws.cell(r, 11).value)
    return {
        "_k": k,
        "Plaka": cell_str(plate) or str(plate).strip(),
        "Marka ve Model": bm,
        "Model Yılı": yil,
        "Muayne Bitiş": ws.cell(r, 9).value,
        "_firma": firma,
        "_kurum_bank": kurum,
    }


def row_med(ws, r):
    plate = ws.cell(r, 4).value
    k = norm_plate(plate)
    if not k:
        return {}
    marka = cell_str(ws.cell(r, 10).value) or ""
    tip = cell_str(ws.cell(r, 11).value) or ""
    bm = " ".join(x for x in (marka, tip) if x).strip() or None
    yil = ws.cell(r, 9).value
    if isinstance(yil, float) and yil == int(yil):
        yil = int(yil)
    kk = kasko_kodu_from_tsb(ws.cell(r, 7).value, ws.cell(r, 8).value)
    unvan = cell_str(ws.cell(r, 2).value)
    return {
        "_k": k,
        "Plaka": cell_str(plate) or str(plate).strip(),
        "Marka ve Model": bm,
        "Model Yılı": yil,
        "Kasa Tipi": cell_str(ws.cell(r, 6).value),
        "Kasko Kodu": kk,
        "_unvan": unvan,
        "Araç Alış Bedeli": ws.cell(r, 14).value,
        "Muayne Bitiş": ws.cell(r, 22).value,
        "Tramer Kaydı": cell_str(ws.cell(r, 23).value),
    }


def row_kasko_dup(ws, r):
    """KASKO listesindeki UNVAN; MEDİSA ile aynı yapı."""
    plate = ws.cell(r, 4).value
    k = norm_plate(plate)
    if not k:
        return {}
    unvan = cell_str(ws.cell(r, 2).value)
    return {"_k": k, "_unvan_kasko": unvan}


def apply_fields(target: list, headers: list, src: dict, over: bool):
    skip = {"_k", "_firma", "_unvan", "_unvan_kasko", "_kurum_bank"}
    for i, h in enumerate(headers):
        if not h or not isinstance(h, str):
            continue
        f = h.strip()
        if f in skip or f.startswith("_"):
            continue
        if f not in src or src[f] is None:
            continue
        if not over:
            if target[i] is not None and cell_str(target[i]) is not None:
                continue
        target[i] = src[f]


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    pt, ps, pm, pk = pick_template(), pick_senay(), pick_med(), pick_kasko()
    exclude = {pt.resolve(), ps.resolve(), pm.resolve(), pk.resolve()}

    wb = openpyxl.load_workbook(pt, data_only=True)
    headers = read_headers(wb["Arac Yukleme"])
    wb.close()

    idx_sube = header_col_exact(headers, "Şube", "SUBE")
    idx_kul = header_col_exact(headers, "Kullanıcı", "KULLANICI")
    idx_kredi_bank = header_col_contains(
        headers, "Kredi Rehin Bankası", ("TELEFON", "MAIL", "MAİL")
    )
    if idx_kredi_bank is None:
        idx_kredi_bank = header_col_contains(headers, "Bankası", ("TELEFON",))

    # plaka -> satır + meta (birleşik kullanıcı / şube için)
    master: dict[str, list] = {}
    meta_kul: dict[str, list[str]] = defaultdict(list)
    meta_firma: dict[str, list[str]] = defaultdict(list)
    meta_unvan: dict[str, list[str]] = defaultdict(list)
    meta_kurum: dict[str, list[str]] = defaultdict(list)

    def touch(k):
        if k not in master:
            master[k] = [None] * len(headers)

    wb = openpyxl.load_workbook(ps, data_only=True)
    ws = wb.active
    for r in range(2, ws.max_row + 1):
        d = row_senay(ws, r)
        if not d:
            continue
        k = d["_k"]
        touch(k)
        apply_fields(master[k], headers, d, True)
        if d.get("_firma"):
            meta_firma[k].append(d["_firma"])
            meta_kul[k].append(d["_firma"])
        if d.get("_kurum_bank"):
            meta_kurum[k].append(d["_kurum_bank"])
    wb.close()

    wb = openpyxl.load_workbook(pm, data_only=True)
    ws = wb.active
    for r in range(2, ws.max_row + 1):
        d = row_med(ws, r)
        if not d:
            continue
        k = d["_k"]
        touch(k)
        apply_fields(master[k], headers, d, True)
        if d.get("_unvan"):
            meta_unvan[k].append(d["_unvan"])
            meta_kul[k].append(d["_unvan"])
    wb.close()

    wb = openpyxl.load_workbook(pk, data_only=True)
    ws = wb.active
    for r in range(2, ws.max_row + 1):
        d = row_kasko_dup(ws, r)
        if not d:
            continue
        k = d["_k"]
        touch(k)
        if d.get("_unvan_kasko"):
            meta_unvan[k].append(d["_unvan_kasko"])
            meta_kul[k].append(d["_unvan_kasko"])
    wb.close()

    extras = iter_extra_plate_name_files(exclude)
    extra_names = load_extra_name_rows(extras)
    for k, names in extra_names.items():
        touch(k)
        meta_kul[k].extend(names)

    # Kullanıcı: FİRMA (şirket/şube adı) + UNVAN + ek dosya adları
    for k in list(master.keys()):
        row = master[k]
        if idx_sube is not None:
            if meta_firma[k]:
                row[idx_sube] = merge_unique_labels(*meta_firma[k])
            else:
                row[idx_sube] = merge_unique_labels(*meta_unvan[k])

        if idx_kul is not None:
            row[idx_kul] = merge_unique_labels(
                *meta_kul[k],
                row[idx_kul],
            )

        if idx_kredi_bank is not None and meta_kurum[k]:
            row[idx_kredi_bank] = merge_unique_labels(
                row[idx_kredi_bank],
                *meta_kurum[k],
            )

    wb_out = openpyxl.Workbook()
    wo = wb_out.active
    wo.title = "Araclar_Master"
    for c, h in enumerate(headers, 1):
        wo.cell(1, c, h)
    keys = sorted(master.keys())
    for ri, k in enumerate(keys, 2):
        for ci, v in enumerate(master[k], 1):
            wo.cell(ri, ci, v)

    wbk = openpyxl.load_workbook(pk, data_only=True)
    sk = wbk[wbk.sheetnames[0]]
    wk = wb_out.create_sheet("Kasko_TSB")
    for row in sk.iter_rows(values_only=True):
        wk.append(list(row))
    wbk.close()

    if OUT_FILE.exists():
        OUT_FILE.unlink()
    wb_out.save(OUT_FILE)
    wb_out.close()

    print("OK", OUT_FILE)
    print("  plaka_sayisi", len(keys))
    print("  ek_plaka_isim_kaynagi", len(extras), "dosya/sayfa")
    for path, sn, pc, nc in extras[:8]:
        print("   -", path.name, "/", sn, "plaka_col", pc, "isim_cols", nc)


if __name__ == "__main__":
    main()
